package com.yamaha.Team_Planner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
